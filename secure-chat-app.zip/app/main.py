from flask import Flask, request, render_template, session
from Crypto.Cipher import AES
import base64
import os

app = Flask(__name__)
app.secret_key = os.urandom(16)  # Chave para sessão e CSRF

# Chave AES de 16 bytes (128 bits)
KEY = b'SuaChaveSecreta123456'

def encrypt_message(message):
    cipher = AES.new(KEY, AES.MODE_EAX)
    nonce = cipher.nonce
    ciphertext, tag = cipher.encrypt_and_digest(message.encode('utf-8'))
    return base64.b64encode(nonce + ciphertext).decode('utf-8')

def decrypt_message(encrypted_message):
    encrypted_data = base64.b64decode(encrypted_message)
    nonce = encrypted_data[:16]
    ciphertext = encrypted_data[16:]
    cipher = AES.new(KEY, AES.MODE_EAX, nonce=nonce)
    return cipher.decrypt(ciphertext).decode('utf-8')

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        token = request.form.get('csrf_token')
        if token != session.get('csrf_token'):
            return "CSRF Detectado!", 403

        mensagem = request.form.get('message')
        mensagem_criptografada = encrypt_message(mensagem)
        mensagem_descriptografada = decrypt_message(mensagem_criptografada)

        return render_template('index.html',
                               csrf_token=session['csrf_token'],
                               encrypted_message=mensagem_criptografada,
                               original_message=mensagem_descriptografada)

    session['csrf_token'] = os.urandom(16).hex()
    return render_template('index.html', csrf_token=session['csrf_token'])

if __name__ == '__main__':
    app.run(debug=True)
